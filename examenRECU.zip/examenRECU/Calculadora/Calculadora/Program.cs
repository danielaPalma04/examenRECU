﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero1, numero2;
            string operacion;

            Console.WriteLine("Por favor, ingrese el primer numero: ");
            numero1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Por favor, ingrese el segundo numero: ");
            numero2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Por favor, ingrese el la opcion a realizar ");
            Console.WriteLine("+, -, *, /");
            operacion = Console.ReadLine();
            Console.ReadKey();

            switch (operacion)
            {
                case "+":
                    Console.WriteLine("{0} + {1} = {2}", numero1, numero2, numero1 + numero2);
                    Console.ReadKey();
                    break;
                case "-":
                    Console.WriteLine("{0} - {1} = {2}", numero1, numero2, numero1 - numero2);
                    Console.ReadKey();
                    break;
                case "*":
                    Console.WriteLine("{0} * {1} = {2}", numero1, numero2, numero1 * numero2);
                    Console.ReadKey();
                    break;
                case "/":
                    if (numero2 != 0)
                    {
                        Console.WriteLine("{0} / {1} = {2}", numero1, numero2, numero1 / numero2);
                    }
                    else
                    {
                        Console.WriteLine("no se puede dividir en cero");
                    }
                    break;
                default:
                    Console.WriteLine("Operacion no válida");
                    break;
                    Console.ReadKey();
            }
        }
    }
}
